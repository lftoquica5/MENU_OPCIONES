<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOLICITAR SERVICIO</title>
    <link rel="stylesheet" href="css/style2.css">
<body>
            <form action="home">
                <label for="fname">Nombres</label>
                <input type="text" id="fname" name="firstname" placeholder="Tu nombre">
                <br>
                <label for="lname">Apellidos</label>
                <input type="text" id="lname" name="lastname" placeholder="tu apellido">
                <br>
                <label for="email">correo electronico</label>
                <input type="email" id="lname" name="lastname" placeholder="tu apellido">
                <br>
                <label for="age">Fecha de recogida</label>
                <input type="date" id="pedido" name="pedido">
                <br>
                <label for="precio">Valor estimado del producto a enviar</label>
                <input id="number" type="number" name="precio" placeholder="valor estimado">
                <br>
                
                
                <input href="home" type="submit" value="COTIZAR">
            </form>
</body>
