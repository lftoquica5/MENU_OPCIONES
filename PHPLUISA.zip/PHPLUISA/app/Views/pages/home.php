
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
    <title>IN CAR GO</title>
    <link rel="stylesheet" href="css/style.css">

</head>

<body class="body">
    <section>
        <article>
         <p class="parrafoPrincipal">
            In Car Go es una empresa de envíos en Bogotá, nos caracterizamos por prestar un
            servicio de calidad, teniendo como premisa el cuidado de los productos, dando a nuestros
            clientes la confianza y tranquilidad que se merecen.
            Todos nuestros envíos los realizamos en Motocarros, para garantizar que en el transporte no se deterioren y tengan un buen
            manejo.
            </p>
            <div><img class="imagenPrincipal" src="IMG/incar.png" alt="">  
        </article>
    </section>

</body>

