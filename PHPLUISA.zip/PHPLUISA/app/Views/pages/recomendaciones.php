      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
      <title>RECOMENDACIONES</title>
      <style>

        .contenedor-principal {
          display: flex;
          max-width: 95%;
          margin: 0 auto;
        }
        .contenedor-principal__izquierda{
        background-color: #fccf10;
          padding: 10px;
        }
        .contenedor-principal__derecha {
            background-color: #fccf10;
          padding: 10px;
        }

        .contenedor-principal__parrafo{
            font-size: calc(1em + 1vw);
        }


      </style>
    </head>
    <body>
    <div class="contenedor-principal">
      <div class="contenedor-principal__izquierda">
        <p class="contenedor-principal__parrafo">
        <img src="IMG/motocarro.jpg" alt="">          </p>
      </div>
      <div class="contenedor-principal__derecha">
        <p class="contenedor-principal__parrafo">
        • Debes enviar tu producto lo mejor empacado
        posible.<br>
        • El pago lo puedes realizar antes o después de
        prestar el servicio, en efectivo o transferencia.<br>
        • El seguimiento en tiempo real lo realizamos desde
        nuestra plataforma de In Car Go, le notificamos a
        nuestros clientes siempre y cuando se presente
        alguna anomalía, o el cliente solicite la ubicación.<br>
        • La entrega de los productos se enrutan según el
        itinerario que se vaya teniendo durante el día,
        todos los pedidos se entregan el mismo día.<br>
        • Recomendamos estar seguros de la dirección que
        se envía, para no tener contratiempos en las
        entregas. </p>
    </div>

</div>

