<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
<style>
body {
  margin: 0;
  font-family: 'Bebas Neue', sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #fccf10;
  
}

.topnav a {
  float: left;
  color: #333333;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 25px;
}

.topnav a:hover {
  background-color: #333333;
  color: #fccf10;
}

.topnav a.active {
  background-color: #1b1c1c;
  color: #fccf10;
}
</style>
</head>
<body>

<div class="topnav">
  <a href="home" class="active">IN CAR GO</a>
  <a href="seguimiento">SOLICITAR SERVICIO</a>
  <a href="recomendaciones">RECOMENDACIONES</a>
  <a href="ruta">MI PEDIDO</a>
</div>
<br>
</body>