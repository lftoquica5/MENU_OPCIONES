<br>
<br>
<style>
        .seccion-final {
          display: flex;
          justify-content: center;
        }
        .seccion-final__parrafo {
          border: 1px solid;
        }
      </style>
      
      <footer class="seccion-final">
      <em><b>&copy; PHP- LUISA FERNANDA TOQUICA ESTRADA - 2023</em>
    </footer>
<br>
</body>
</html>